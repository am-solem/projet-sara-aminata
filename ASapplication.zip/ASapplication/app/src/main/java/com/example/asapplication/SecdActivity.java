package com.example.asapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecdActivity extends AppCompatActivity {
    private String leprenom, lenom;
    private TextView textprenom, textnom,tail,poi,rst;
    private Button btn,btt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secd);


            lenom=getIntent().getStringExtra("lenom");
            leprenom=getIntent().getStringExtra("leprenom");

            textnom = (TextView) findViewById(R.id.tv3);
            textprenom=(TextView)findViewById(R.id.tv6);
            tail=(TextView)findViewById(R.id.tail);
            rst=(TextView)findViewById(R.id.textView8);
            poi=(TextView)findViewById(R.id.poi);
            btn = (Button)findViewById(R.id.button2);
            btt = (Button)findViewById(R.id.button3);

            textnom.setText(lenom);
            textprenom.setText(leprenom);

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Double lataille = Double.parseDouble(tail.getText().toString());
                    Double lepoids = Double.parseDouble(poi.getText().toString());
                    Double imc = lepoids/(lataille*lataille);
                    rst.setText("M."+lenom+" votre imc est: "+imc);
                }
            });
            btt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    rst.setText("vov infos ne sont pas dispo");
                }
            });

        }
    }
